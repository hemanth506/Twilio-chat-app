// require("dotenv").config();
import axios from "axios";

export const contactWebchatOrchestrator = async (customerFriendlyName) => {
  console.log("Calling Webchat Orchestrator", customerFriendlyName);

  const params = new URLSearchParams();
  params.append("AddressSid", process.env.REACT_APP_FLEX_CHAT_ADDRESS_ID);
  params.append("ChatFriendlyName", "Webchat widget");
  params.append("CustomerFriendlyName", customerFriendlyName);
  params.append(
    "PreEngagementData",
    JSON.stringify({
      friendlyName: customerFriendlyName,
    })
  );

  let conversationSid;
  let identity;

  try {
    const res = await axios.post(
      `https://flex-api.twilio.com/v2/WebChats`,
      params,
      {
        auth: {
          username: process.env.REACT_APP_TWILIO_ACCOUNT_SID,
          password: process.env.REACT_APP_TWILIO_AUTH_TOKEN,
        },
      }
    );
    console.log(
      "🚀 ~ file: webChat.js:33 ~ contactWebchatOrchestrator ~ res:",
      res
    )(({ identity, conversation_sid: conversationSid } = res.data));
  } catch (e) {
    console.log(
      "Something went wrong during the orchestration:",
      e.response?.data?.message
    );
    throw e.response.data;
  }

  console.log("Webchat Orchestrator successfully called");

  return {
    conversationSid,
    identity,
  };
};
