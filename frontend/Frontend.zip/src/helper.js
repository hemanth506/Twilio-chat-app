import { Client as ConversationsClient } from "@twilio/conversations";
import { contactWebchatOrchestrator } from "./webChat";
import * as Twilio from "twilio";

const getToken = async (identity) => {
  const response = await fetch(`http://localhost:5000/auth/user/${identity}`);
  const responseJson = await response.json();
  return responseJson.token;
};

const getTwilioClient = () => {
  return new Twilio(
    process.env.REACT_APP_TWILIO_API_KEY_SID,
    process.env.REACT_APP_TWILIO_API_KEY_SECRET,
    {
      accountSid: process.env.REACT_APP_TWILIO_ACCOUNT_SID,
    }
  );
};

export const sendUserMessage = (conversationSid, identity, messageBody) => {
  return getTwilioClient()
    .conversations.conversations(conversationSid)
    .messages.create({
      body: messageBody,
      author: identity,
      xTwilioWebhookEnabled: true,
    })
    .then(() => {
      console.log("(async) User message sent");
    })
    .catch((e) => {
      console.log(`(async) Couldn't send user message: ${e?.message}`);
    });
};

export let conClient;
export const initConversationsClient = async (
  name,
  setStatusString,
  setIsConnected,
  setIdentiyState,
  setConverSidState
) => {
  try {
    const { conversationSid, identity } = await contactWebchatOrchestrator(
      name
    );
    setIdentiyState(identity);
    setConverSidState(conversationSid);
    console.log("🚀 ~ file: helper.js:17 ~ conversationSid:", conversationSid);
  } catch (e) {
    console.log("🚀 ~ file: helper.js:22 ~ e:", e);
    // throw new Error("Error in initConversationsClient", e);
  }

  // conClient = new ConversationsClient(token);
  const token = await getToken(identity);

  setStatusString("Connecting to Twilio...");
  setStatusString("You are connected.");
  setIsConnected(true);

  // conClient.on("connectionStateChanged", (state) => {
  //   console.log("🚀 ~ file: helper.js:18 ~ conClient.on ~ state:", state);
  //   switch (state) {
  //     case "connected":
  //       setStatusString("You are connected.");
  //       setIsConnected(true);
  //       break;
  //     case "disconnecting":
  //       setStatusString("Disconnecting from Twilio...");
  //       break;
  //     case "disconnected":
  //       setStatusString("Disconnected.");
  //       break;
  //     case "denied":
  //       setStatusString("Failed to connect.");
  //       break;
  //   }
  // });
};

export const createConversationFunction = async (
  convosClient,
  setActiveConversation
) => {
  console.log("🚀 ~ file: helper.js:49 ~ convosClient:", convosClient);
  console.log(
    "🚀 ~ file: helper.js:50 ~ setActiveConversation:",
    setActiveConversation
  );
};
