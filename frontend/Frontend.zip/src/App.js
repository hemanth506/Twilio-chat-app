import "./App.css";
import { useState } from "react";
import {
  conClient,
  initConversationsClient,
  createConversationFunction,
} from "./helper.js";
import Conversation from "./Conversation";

function App() {
  const [statusString, setStatusString] = useState("");
  const [activeConversation, setActiveConversation] = useState(null);
  const [name, setName] = useState("");
  const [nameRegistered, setNameRegistered] = useState(false);
  const [isConnected, setIsConnected] = useState(false);
  const [identiyState, setIdentiyState] = useState(null);
  const [converSidState, setConverSidState] = useState(null);

  const registerName = async (
    tempSetStatusString,
    tempSetIsConnected,
    tempSetIdentiyState,
    tempSetConverSidState
  ) => {
    setNameRegistered(true);
    await initConversationsClient(
      name,
      tempSetStatusString,
      tempSetIsConnected,
      tempSetIdentiyState,
      tempSetConverSidState
    );
  };

  const createConversation = async () => {
    try {
      await conClient.getUser("aa");
      await conClient.getUser("bb");
    } catch {
      console.error("Waiting for Mohendren and Hemanth client sessions");
      return;
    }

    try {
      console.log(
        "🚀 ~ file: App.js:40 ~ createConversation ~ conClient:",
        conClient
      );
      const newConversation = await conClient.conversation.conversation.create({
        friendlyName: "chat",
      });
      console.log(
        "🚀 ~ file: App.js:41 ~ createConversation ~ newConversation:",
        newConversation
      );
      const joinedConversation = await newConversation
        .join()
        .catch((err) => console.log(err));
      await joinedConversation
        .add("Mohendren")
        .catch((err) => console.log("error: ", err));
      await joinedConversation
        .add("Hemanth")
        .catch((err) => console.log("error: ", err));
      setActiveConversation(joinedConversation);
    } catch {
      setActiveConversation(
        await conClient.getConversationByUniqueName("chat")
      );
    }
  };

  return (
    <div className="App">
      <h1>Welcome to React Chat App{nameRegistered && `, ${name}`}!</h1>
      <p>{statusString}</p>
      {!nameRegistered && (
        <div>
          <input
            type="text"
            placeholder="Enter your name"
            onChange={(e) => setName(e.target.value)}
            value={name}
          />
          <button
            onClick={() =>
              registerName(
                setStatusString,
                setIsConnected,
                setIdentiyState,
                setConverSidState
              )
            }
          >
            Register name
          </button>
        </div>
      )}
      {nameRegistered && isConnected && (
        <div>
          <button onClick={createConversation}>Join Chat</button>
        </div>
      )}
      {nameRegistered && isConnected && (
        <Conversation
          activeConversation={activeConversation}
          name={name}
          identiyState={identiyState}
          converSidState={converSidState}
        />
      )}
    </div>
  );
}

export default App;
